# MATH.ID Android

Aplikasi Android wrapper modern untuk https://www.math.id/

## Fitur
- WebView modern berbasis Kotlin
- Login/cookie persisten
- JavaScript + DOM storage
- Upload file
- Download file
- Pull-to-refresh
- Offline state
- Deep link math.id
- External links dibuka via aplikasi/browser eksternal
- Optimasi equation/KaTeX/MathJax
- Dukungan fullscreen layout untuk halaman CBT/Promath
- Android back navigation yang aman

## Build APK

### Cara paling mudah
1. Install Android Studio.
2. Buka folder project ini.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build APK(s)**.
5. APK debug akan berada di:
   `app/build/outputs/apk/debug/app-debug.apk`

### Release / Play Store
Gunakan:
**Build > Generate Signed Bundle / APK**

Pilih:
- APK untuk instal manual
- Android App Bundle (AAB) untuk Google Play

## Catatan keamanan ujian
Aplikasi ini dapat memberikan pengalaman ujian yang lebih terkendali daripada browser biasa, tetapi pemblokiran total tombol Home/Recent Apps membutuhkan mode kiosk / Device Owner / MDM pada perangkat sekolah.
