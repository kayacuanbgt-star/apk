@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle belum tersedia. Buka project ini di Android Studio lalu pilih Build ^> Build APK(s).
  pause
  exit /b 1
)
gradle assembleDebug
if exist app\build\outputs\apk\debug\app-debug.apk (
  echo.
  echo APK berhasil dibuat:
  echo %cd%\app\build\outputs\apk\debug\app-debug.apk
)
pause
